const name: string = 'francisco';
let hpPoints: number | "FULL" = 95;
const isAlive: boolean = true;

hpPoints = 'FULL';


console.log({//console log lleva parentesis...
    name, hpPoints, isAlive
})

export{}