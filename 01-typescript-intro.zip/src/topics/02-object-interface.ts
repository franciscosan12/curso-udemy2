

const skills: string[] = ['Bash','Counter','Healing'];

interface Character{
    name: string;
    hp: number,
    skills: string[];
    hometown?: string;
}
const frank: Character = {
    name: 'frank',
    hp: 100,
    skills: ['Bash','Counter']
};

frank.hometown = 'guadalajara';

console.table(frank)

export{};
