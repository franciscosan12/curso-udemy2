interface audioplayer{
    audioVolume: number;
    songDuration: number;
    song: string;
    details: Details;
  
  }
  
  interface Details{
    author: string;
    year: number;
  }
  
  const audioPlayer: audioplayer = {
    audioVolume: 90;
    songDuration: 36;
    song: "Mess";
    details: {
      author: 'Sd Sheraan';
      year: 2015;
    }
  }
  
  console.log('Song: ', audioPlayer.song);
  
  
  export{};